#perl script to sort table of data from arcgis for tolbachik lava flow

#open and read the input file
open (IN, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset = <IN>;


foreach $line (@dataset) {
    ($x, $y, $base_elevation, $flow_elevation) = split " ", $line;

    $thickness = $flow_elevation - $base_elevation;

    print"$x $y $thickness \n";
}
