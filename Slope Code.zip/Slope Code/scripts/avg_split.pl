#code to split slope data from multislope output


#open and read the input file
open (IN, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset = <IN>;

#open the lines of data and assign easting, northing, and slope method
foreach $line (@dataset) {
    ($x, $y, $avg, $avgE, $avgN) = split " ", $line;
    
    #print selected slope data
    print"$x $y $avg \n";
}
