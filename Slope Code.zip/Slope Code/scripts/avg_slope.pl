#Steven Rizo
#4/26/2018

#perl script to calculate the average slope of an NxN grid


#2: average slope for NxN grid
#Sx = sum from i=1 -> N-1, j = 1 -> N [Z(i,j) - Z(i+1,j)] / [N*(N-1)]
#Sy = sum from i=1 -> N, j = 1 -> N-1 [Z(i,j) - Z(i,j+1)] / [N*(N-1)]
#S = sqrt(Sx^2 + Sy^2)




#OUTPUT FORMAT: Easting Northing AverageSlope AverageEastingGradient AverageNorthingGradient




#open and read the input file
open (IN, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset = <IN>;

use Math::Trig;

#easting and norting data for first line of dataset (or any value that is within the data)
my $first_easting = 568207.828782566;
my $first_northing = 6185501.59856441;
my $first_elevation = 379.0571899414;

#define the grid spacing in meters. calculations assume equal grid spacing for x and y where dx = dy
my $spacing = 16;

#initialize matrix for slope calculation
my @E;

#initialize min and max values for Easting (x) and Northing (y) 
my $x_min = $first_easting;
my $x_max = $first_easting;
my $y_min = $first_northing;
my $y_max = $first_northing;
my $e_max = $first_elevation;
my $e_min = $first_elevation;

#define size of N by N matrix for calculation and calculate data point radius for calculation
my $N = 13;
my $R = ($N - 1)/2;

#define minimum increment of change for iteration of curve-fitting variables, should be 0.01 or lower
my $increment = 0.001;

#assign correct decimal places for calculations, number value = number of decimal places in minimum increment
my $decimal = "%.3f";

#define acceptable error in RMS as the minimum change to end looping for solution
my $error = 0.000001;

#assign value for matrix points with no data
my $nodata = 0;

#open the lines of data and and find minimum and maximum values for easting and northing
foreach $line (@dataset) {
    ($x, $y, $elevation) = split " ", $line;

    if ($x < $x_min) {
        $x_min = $x;
    }
    if ($x > $x_max) {
        $x_max = $x;
    }
    if ($y < $y_min) {
        $y_min = $y;
    }
    if ($y > $y_max) {
        $y_max = $y;
    }
    if ($elevation > $e_max) {
        $e_max = $elevation;
    }
    if ($elevation < $e_min) {
        $e_min = $elevation;
    }
}

#set matrix size based on data extent
my $Mx = ($x_max - $x_min) / $spacing;
my $My = ($y_max - $y_min) / $spacing;

#create initial elevation matrix of nodata values
for ($i = 0; $i <= $Mx; $i++) {
    for ($j = 0; $j <= $My; $j++) {
        $E[$i][$j] = $nodata;
    }
}

#open the lines of data and add data to elevation matrix
foreach $line (@dataset) {
    ($x, $y, $elevation) = split " ", $line;
    
    #translate xyz data into indexe grid matrix format
    $grid_x = ($x - $x_min) / $spacing;
    $grid_y = ($y - $y_min) / $spacing;
    $E[$grid_x][$grid_y] = $elevation;
}

#begin loop for calculation at each valid data point
for ($Ix = $R; $Ix <= ($Mx - $R); $Ix++) {
    for ($Iy = $R; $Iy <= ($My - $R); $Iy++) {

        #check if all data points within range have actual data values
        $data_check = 1;
        for ($lx = ($Ix - $R); $lx <= ($Ix + $R); $lx++) {
            for ($ly = ($Iy - $R); $ly <= ($Iy + $R); $ly++) {
                if ($E[$lx][$ly] <= $nodata) {
                    $data_check = 0;
                }
            }
        }
        if ($data_check > 0) {



        #print x and y value of calculation
        $x_calc = $Ix * $spacing + $x_min;
        $y_calc = $Iy * $spacing + $y_min;
        print"$x_calc $y_calc ";

        #BEGIN SLOPE CALCULATION
	   #sum slopes in the x direction
	   $x_sum = 0;
	   for ($y = ($Iy - $R); $y <= ($Iy + $R); $y++) {
 	      for ($x = ($Ix - $R); $x < ($Ix + $R); $x++) {
 	          $x_sum = $x_sum + ($E[$x+1][$y] - $E[$x][$y]) / $spacing;
 	      }
	   }

	   #sum slopes in the y direction
	   $y_sum = 0;
	   for ($x = ($Ix - $R); $x <= ($Ix + $R); $x++) {
  	     for ($y = ($Iy - $R); $y < ($Iy + $R); $y++) {
  	         $y_sum = $y_sum + ($E[$x][$y+1] - $E[$x][$y]) / $spacing;
  	     }
	   }

	   #calculate average slopes in x and y directions
	   $num_sum = $N * ($N - 1);
	   $x_avg = $x_sum / $num_sum;
	   $y_avg = $y_sum / $num_sum;

	   #calculate slope from x and y direction averages
	   $av_slope = sqrt($x_avg**2 + $y_avg**2);

	   #output result from average slope method
	   my $av_rad = atan($av_slope);
	   my $av_angle = rad2deg($av_rad);
	   print"$av_angle $x_avg $y_avg \n";

        }
    }
}