#perl script to sort table of data from arcgis for multislope calcuations

#for use with data exported from an arcgis table as a .csv text file
#before running: open the .csv files from arcgis in excel or a similar program, delete the rowid column, and save the file

#expected format of input .csv files is "rounded_elevation, easting, northing, elevation"
#reformats data to "easting northing elevation"

#open and read the input file
open (IN, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset = <IN>;


foreach $line (@dataset) {
    ($x, $y, $elevation) = split ",", $line;
    if($elevation > 0) {
        #print reformatted data
        $elevation = cleanlines($elevation);
        print"$x $y $elevation \n";
    }
}



sub cleanlines{

    my $text = shift;

    $text =~ s/\r/ /; #replace \r with space
    $text =~ s/\n/ /; #replace \n with space
    $text =~ s/  / /g; #replace double-spaces with single space

    return $text;
}
