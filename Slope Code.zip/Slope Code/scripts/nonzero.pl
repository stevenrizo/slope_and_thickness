#perl script to remove zero slope values for slope vs thickness plotting


#open and read the input file
open (IN1, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset = <IN1>;


foreach $line (@dataset) {
    ($easting, $northing, $baseslope, $flowslope, $thickness, $m1) = split " ", $line;
	if ($baseslope > 0) {
		if ($flowslope > 0) {
			print "$easting $northing $baseslope $flowslope $thickness \n";
		}
	}
}
