#Steven Rizo
#4/26/2018

#perl script to recreate the base surface of a lava flow using the elevation outside of the flow (flow removed) and the calculated average slope within the flow

#the first input file needs to be the elevation outside of the flow, and the second input file should be the slope calculations

#OUTPUT FORMAT: Easting Northing Elevation




#open and read the input files
open (IN1, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset1 = <IN1>;

open (IN2, "<$ARGV[1]") || die ("Cannot open $ARGV[1]: $!");
@dataset2 = <IN2>;


#easting and norting data for first line of dataset (or any value that is within the data)
my $first_easting = 568207.828782566;
my $first_northing = 6185501.59856441;
my $first_elevation = 379.0571899414;

#define the grid spacing in meters. calculations assume equal grid spacing for x and y where dx = dy
my $spacing = 16;

#initialize matrix of elevation
my @E;

#initialize matrices for slope data
my @Seasting;
my @Snorthing;

#initialize min and max values for Easting (x) and Northing (y) 
my $x_min = $first_easting;
my $x_max = $first_easting;
my $y_min = $first_northing;
my $y_max = $first_northing;
my $e_max = $first_elevation;
my $e_min = $first_elevation;

#assign value for matrix points with no data
my $nodata = 0;

#open the lines of data and and find minimum and maximum values for easting and northing
foreach $line (@dataset1) {
    ($x, $y, $elevation) = split " ", $line;

    if ($x < $x_min) {
        $x_min = $x;
    }
    if ($x > $x_max) {
        $x_max = $x;
    }
    if ($y < $y_min) {
        $y_min = $y;
    }
    if ($y > $y_max) {
        $y_max = $y;
    }
    if ($elevation > $e_max) {
        $e_max = $elevation;
    }
    if ($elevation < $e_min) {
        $e_min = $elevation;
    }
}

#set matrix size based on data extent
my $Mx = ($x_max - $x_min) / $spacing;
my $My = ($y_max - $y_min) / $spacing;

#create initial matrices of nodata values
for ($i = 0; $i <= $Mx; $i++) {
    for ($j = 0; $j <= $My; $j++) {
        $E[$i][$j] = $nodata;
        $Seasting[$i][$j] = $nodata;
        $Snorthing[$i][$j] = $nodata;
    }
}

#open the lines of elevation data and add data to elevation matrix
foreach $line (@dataset1) {
    ($x, $y, $elevation) = split " ", $line;
    
    #translate xyz data into indexe grid matrix format
    $grid_x = ($x - $x_min) / $spacing;
    $grid_y = ($y - $y_min) / $spacing;
    $E[$grid_x][$grid_y] = $elevation;
}

#open the lines of slope data and add data to slope matrices
foreach $line (@dataset2) {
    ($x, $y, $Average, $AverageSeasting, $AverageSnorthing) = split " ", $line;
    
    #translate xyz data into indexe grid matrix format
    $grid_x = ($x - $x_min) / $spacing;
    $grid_y = ($y - $y_min) / $spacing;
    $Seasting[$grid_x][$grid_y] = $AverageSeasting;
    $Snorthing[$grid_x][$grid_y] = $AverageSnorthing;
}





#begin loop for elevation interpolation
for ($ix = 0; $ix <= ($Mx); $ix++) {
    for ($iy = 0; $iy <= ($My); $iy++) {

	#check if the point of elevation has data
        if ($E[$ix][$iy] == $nodata) {

	#print x and y value of calculation
        $x_calc = $ix * $spacing + $x_min;
        $y_calc = $iy * $spacing + $y_min;
        print"$x_calc $y_calc ";

		#check calculation points and, if there is no elevation data, interpolate the data for this point first
		#easting check
		if ($E[$ix-1][$iy] == $nodata) {
			if ($E[$ix-2][$iy] == $nodata) {
				if ($E[$ix-3][$iy] == $nodata) {
					$E[$ix-3][$iy] = ( ($Seasting[$ix-3][$iy]*$spacing + $E[$ix-4][$iy]) + ($Snorthing[$ix-3][$iy]*$spacing + $E[$ix-3][$iy-1]) ) / 2;
				} else {
					$E[$ix-2][$iy] = ( ($Seasting[$ix-2][$iy]*$spacing + $E[$ix-3][$iy]) + ($Snorthing[$ix-2][$iy]*$spacing + $E[$ix-2][$iy-1]) ) / 2;
				}
			} else {
				$E[$ix-1][$iy] = ( ($Seasting[$ix-1][$iy]*$spacing + $E[$ix-2][$iy]) + ($Snorthing[$ix-1][$iy]*$spacing + $E[$ix-1][$iy-1]) ) / 2;
			}
		}
		#northing check
		if ($E[$ix][$iy-1] == $nodata) {
			if ($E[$ix][$iy-2] == $nodata) {
				if ($E[$ix][$iy-3] == $nodata) {
					$E[$ix][$iy-3] = ( ($Seasting[$ix][$iy-3]*$spacing + $E[$ix-1][$iy-3]) + ($Snorthing[$ix][$iy-3]*$spacing + $E[$ix][$iy-4]) ) / 2;
				} else {
					$E[$ix][$iy-2] = ( ($Seasting[$ix][$iy-2]*$spacing + $E[$ix-1][$iy-2]) + ($Snorthing[$ix][$iy-2]*$spacing + $E[$ix][$iy-3]) ) / 2;
				}
			} else {
				$E[$ix][$iy-1] = ( ($Seasting[$ix][$iy-1]*$spacing + $E[$ix-1][$iy-1]) + ($Snorthing[$ix][$iy-1]*$spacing + $E[$ix][$iy-2]) ) / 2;
			}
		}


		#calculate new elevation based on the the average of the change in elevation from the previous easting and northing points
		$new_elevation = ( ($Seasting[$ix][$iy]*$spacing + $E[$ix-1][$iy]) + ($Snorthing[$ix][$iy]*$spacing + $E[$ix][$iy-1]) ) / 2;


		#print new elevation
		print"$new_elevation \n";

		}
    }
}

