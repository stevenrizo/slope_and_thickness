#perl script to merge slope and thickness data files

#slope file format is expected to be "Easting Northing BaseSlope FlowSlope"
#thickness file format is expected to be "Easting Northing Thickness"

#open and read the input file
open (IN1, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset1 = <IN1>;

open (IN2, "<$ARGV[1]") || die ("Cannot open $ARGV[1]: $!");
@dataset2 = <IN2>;


#initialize matrices for data
my @A;
my @B;

#assign data from first data set to a matrix
my $count1 = 0;

foreach $line (@dataset1) {
    ($x1, $y1, $baseSlope, $flowSlope, $m1) = split " ", $line;

	$A[$count1][0] = $x1;
	$A[$count1][1] = $y1;
	$A[$count1][2] = $baseSlope;
	$A[$count1][3] = $flowSlope;

	$count1++;
}


#assign data from second data set to a matrix
my $count2 = 0;
foreach $line (@dataset2) {
    ($x2, $y2, $thickness, $m2) = split " ", $line;
    
    $B[$count2][0] = $x2;
    $B[$count2][1] = $y2;
    $B[$count2][2] = $thickness;
 
    $count2++;
}


#check for similar values and print combined data
for ($i = 0; $i < $count1; $i++) {
    for ($j = 0; $j < $count2; $j++) {

        if ($A[$i][0] == $B[$j][0]) {
            if ($A[$i][1] == $B[$j][1]) {
            print"$A[$i][0] $A[$i][1] $A[$i][2] $A[$i][3] $B[$j][2] \n";

            splice (@B, $j, 1);
            
            $count2 = $count2 -1;
            }
        }

    }
}
