#perl script to merge two data files

#clips the extent of the second input file to points with the same easting and northing as those found in the first data file

#open and read the input file
open (IN1, "<$ARGV[0]") || die ("Cannot open $ARGV[0]: $!");
@dataset1 = <IN1>;

open (IN2, "<$ARGV[1]") || die ("Cannot open $ARGV[1]: $!");
@dataset2 = <IN2>;


#initialize matrices for data
my @A;
my @B;

#assign data from first data set to a matrix
my $count1 = 0;

foreach $line (@dataset1) {
    ($x1, $y1, $z1, $m1) = split " ", $line;

    $B[$count1][0] = $x1;
    $B[$count1][1] = $y1;
    $B[$count1][2] = $z1;

    $count1++;
}


#assign data from second data set to a matrix
my $count2 = 0;
foreach $line (@dataset2) {
    ($x2, $y2, $avg, $avgE, $avgN, $m1) = split " ", $line;

    $A[$count2][0] = $x2;
    $A[$count2][1] = $y2;
    $A[$count2][2] = $avg;
    $A[$count2][3] = $avgE;
    $A[$count2][4] = $avgN;
 
    $count2++;
}


#check for similar values and print combined data
for ($i = 0; $i < $count2; $i++) {
    for ($j = 0; $j < $count1; $j++) {

        if ($A[$i][0] == $B[$j][0]) {
            if ($A[$i][1] == $B[$j][1]) {

            print"$A[$i][0] $A[$i][1] $A[$i][2] $A[$i][3] $A[$i][4] \n";

            splice (@B, $j, 1);
            
            $count1 = $count1 - 1;
            }
        }

    }
}
