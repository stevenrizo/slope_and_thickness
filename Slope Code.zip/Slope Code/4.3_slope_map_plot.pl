#slope map data plot
#.dat file format should be: Easting Northing Angle


#map boundaries in UTM Coordinates
$west = 568400;
$east = 586800;
$south = 6175800;
$north = 6185400;

#color scale boundary and increment in degrees
$min_angle = 0;
$max_angle = 30;
$increment = 0.5;


#create a color scale for psxy plotting
system"gmt makecpt -Cblue,green,yellow,orange,red -T$min_angle/$max_angle/$increment > generated_data/angle.cpt";




#average base slope map
#create basemap
system"gmt psbasemap -Jx1:75000 -R$west/$east/$south/$north -Ba4000 -BNSEW+t'13x13 Average Base Slope' -Tx1i/4i/0.5i -V -K > plots/base_surface_avg.eps";

#plot slope magnitude data
system"gmt psxy generated_data/base_surface_avg.dat -J -R -Sc0.04 -Cgenerated_data/angle.cpt -V -O -K >> plots/base_surface_avg.eps";

#add colorbar for slope data
system"gmt psscale -J -R -Dx5i/-0.5i+w10c/0.5c+jTC+h -Cgenerated_data/angle.cpt -Bxa5 -O >> plots/base_surface_avg.eps";

#convert .eps file to .png
system"gmt psconvert plots/base_surface_avg.eps -A -Tg -V";



#average flow slope map
#create basemap
system"gmt psbasemap -Jx1:75000 -R$west/$east/$south/$north -Ba4000 -BNSEW+t'13x13 Average Flow Slope' -Tx1i/4i/0.5i -V -K > plots/flow_surface_avg.eps";

#plot slope magnitude data
system"gmt psxy generated_data/flow_surface_avg.dat -J -R -Sc0.04 -Cgenerated_data/angle.cpt -V -O -K >> plots/flow_surface_avg.eps";

#add colorbar for slope data
system"gmt psscale -J -R -Dx5i/-0.5i+w10c/0.5c+jTC+h -Cgenerated_data/angle.cpt -Bxa5 -O >> plots/flow_surface_avg.eps";

#convert .eps file to .png
system"gmt psconvert plots/flow_surface_avg.eps -A -Tg -V";




#makecpt
#-C defines the order of colors to be used for the scale
#-T defines the boundaries and increments of the color gradient


#pscoast
#-J defines the map projection and display in output
#-R defines the region of interest or map boundaries in a west/east/south/north order
#-D defines the resolution of coastal data to be used
#-N defines the level of political boundaries to be added to the map
#-W defines which shoreline to draw and the style of the lines
#-G defines the color fill for inland areas
#-B defines the format of axes plotting and labelling of tick marks
#-L draws and defines the scalebar to be added to the map
#-T draws and defines the size and location of the compass rose on the map
#-V defines the verbose level of how much text displays in command window
#-K informs gmt that more postscript will be added later
#-O informs gmt that the information is being overlayed


#psxy
#-S defines the symbol to be plotted at each location
#-C defines the color gradient used to fill the plotted symbols


#psscale
#-D defines position and dimensions of the scale
#-B defines annotation interval and scale label


#psconvert
#-A adjust the boundary box to the minimum required by image content
#-P forces portrait mode
#-T sets the format to be converted to




