#perl script to run formatting of files for slope calculation

#expected format of input .csv files is "easting, northing, elevation"
#reformats data to "easting northing elevation"


#execute scripts
system"perl scripts/data_format.pl data/full_area_base_16.csv > generated_data/full_base_elevation.dat";

system"perl scripts/data_format.pl data/full_area_flow_16.csv > generated_data/full_flow_elevation.dat";

system"perl scripts/data_format.pl data/flow_surface_16.csv > generated_data/flow_surface_elevation.dat";

system"perl scripts/data_format.pl data/base_surface_16.csv > generated_data/base_surface_elevation.dat";

system"perl scripts/data_format.pl data/area_outside_flow_16.csv > generated_data/area_outside_flow_elevation.dat";
