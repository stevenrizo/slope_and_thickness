#script to prepare slope data for plotting


#split data by method and surface
system"perl scripts/avg_split.pl generated_data/flow_surface_slope.dat > generated_data/flow_surface_avg.dat";

system"perl scripts/avg_split.pl generated_data/base_surface_slope.dat > generated_data/base_surface_avg.dat";
