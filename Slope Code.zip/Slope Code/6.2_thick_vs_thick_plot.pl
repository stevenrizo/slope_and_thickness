#perl script to merge actual and interpolated thickness data


#format for merged files is expected to have the actual thickness first, followed by the interpolated thickness both in "x y z" format


#execute scripts
system"gnuplot scripts/flow_thick_vs_thick.gnu";

system"gnuplot scripts/base_thick_vs_thick.gnu";
