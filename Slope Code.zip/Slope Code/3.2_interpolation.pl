#script to run base surface interpolation using slope and elevation data

system"perl scripts/slope_interpolation.pl generated_data/area_outside_flow_elevation.dat generated_data/flow_slope.dat > generated_data/flow_slope_interpolated_surface.dat";

system"perl scripts/merge.pl generated_data/flow_slope_interpolated_surface.dat generated_data/flow_surface_elevation.dat > generated_data/flow_slope_interpolation_merged.dat";

system"perl scripts/thick.pl generated_data/flow_slope_interpolation_merged.dat > generated_data/flow_slope_interpolated_thickness.dat";


system"perl scripts/slope_interpolation.pl generated_data/area_outside_flow_elevation.dat generated_data/base_slope.dat > generated_data/base_slope_interpolated_surface.dat";

system"perl scripts/merge.pl generated_data/base_slope_interpolated_surface.dat generated_data/flow_surface_elevation.dat > generated_data/base_slope_interpolation_merged.dat";

system"perl scripts/thick.pl generated_data/base_slope_interpolation_merged.dat > generated_data/base_slope_interpolated_thickness.dat";
