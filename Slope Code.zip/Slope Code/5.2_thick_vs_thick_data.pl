#perl script to merge split slope data files



#before running: if the two 3x3 slope map scripts have not been run, then at least the 3x3slope_map_data.pl script must be run to prepare the data to be merged

#format for merged files is expected to have the base slope first, followed by the flow slope
#base slope will be plotted as the x-variable and flow slope will be the y-variable in the figures produced when plotting


#execute scripts
system"perl scripts/merge.pl generated_data/thickness.dat generated_data/flow_slope_interpolated_thickness.dat > generated_data/flow_interpolated_vs_real_thickness_merge.dat";

system"perl scripts/merge.pl generated_data/thickness.dat generated_data/base_slope_interpolated_thickness.dat > generated_data/base_interpolated_vs_real_thickness_merge.dat";
