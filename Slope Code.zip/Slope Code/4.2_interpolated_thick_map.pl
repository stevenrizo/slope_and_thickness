#script to run thickness plotting with a single command

#map boundaries in UTM Coordinates
$west = 568400;
$east = 586800;
$south = 6175800;
$north = 6185400;

#color scale boundary and increment in m
$min_depth = -20;
$max_depth = 100;
$increment = 2;


#create a color scale for psxy plotting
system"gmt makecpt -Cblue,green,yellow,orange,red -T$min_depth/$max_depth/$increment > generated_data/thick.cpt";



#create basemap
system"gmt psbasemap -Jx1:75000 -R$west/$east/$south/$north -Ba4000 -BNSEW+t'Thickness Calculated from Flow Slope Interpolation' -Tx1i/4i/0.5i -V -K > plots/flow_slope_interpolated_thickness.eps";

#plot thickness data as individual points
system"gmt psxy generated_data/flow_slope_interpolated_thickness.dat -J -R -Sc0.04 -Cgenerated_data/thick.cpt -V -O -K >> plots/flow_slope_interpolated_thickness.eps";

#add colorbar for thickness
system"gmt psscale -J -R -Dx5i/-0.5i+w10c/0.5c+jTC+h -Cgenerated_data/thick.cpt -Bxa10 -O >> plots/flow_slope_interpolated_thickness.eps";

#convert .eps file to .png
system"gmt psconvert plots/flow_slope_interpolated_thickness.eps -A -Tg -V";



#create basemap
system"gmt psbasemap -Jx1:75000 -R$west/$east/$south/$north -Ba4000 -BNSEW+t'Thickness Calculated from Base Slope Interpolation' -Tx1i/4i/0.5i -V -K > plots/base_slope_interpolated_thickness.eps";

#plot thickness data as individual points
system"gmt psxy generated_data/base_slope_interpolated_thickness.dat -J -R -Sc0.04 -Cgenerated_data/thick.cpt -V -O -K >> plots/base_slope_interpolated_thickness.eps";

#add colorbar for thickness
system"gmt psscale -J -R -Dx5i/-0.5i+w10c/0.5c+jTC+h -Cgenerated_data/thick.cpt -Bxa10 -O >> plots/base_slope_interpolated_thickness.eps";

#convert .eps file to .png
system"gmt psconvert plots/base_slope_interpolated_thickness.eps -A -Tg -V";

