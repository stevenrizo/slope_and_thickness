#perl script to run gnuplot scrpits to create slope v thickness plots



#before running: data files must be merged through the slopevthick_merge.pl script



#execute scripts
system"gnuplot scripts/avgbase_vs_thick_plot.gnu";

system"gnuplot scripts/avgflow_vs_thick_plot.gnu";