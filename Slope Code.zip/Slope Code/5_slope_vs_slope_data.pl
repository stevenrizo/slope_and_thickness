#perl script to merge previously split slope data files



#before running: the slope_map_data.pl script must be run to prepare the data to be merged

#format for merged files is expected to have the base slope first, followed by the flow slope
#base slope will be plotted as the x-variable and flow slope will be the y-variable in the figures produced when plotting


#execute scripts
system"perl scripts/merge.pl generated_data/base_surface_avg.dat generated_data/flow_surface_avg.dat > generated_data/avg_slope_merge.dat";
