#Steven Rizo
#4/26/2018


#perl script to run all modules for slope and thickness calculation and analysis

#nessecarry input files are listed in the code flowchart, and these file names can be input in the initial format module to be used for the full run

#the NxN calculation grid may be changed in the avg_slope.pl calculation script, and if multiple NxN grids are desired, they can be run in sepaprate folders to keep files from being rewritten


#execute scripts
#system"perl 1_format.pl";

#system"perl 2_calculate.pl";

#system"perl 2.1_thickness_data.pl";

system"perl 3_clip.pl";

#system"perl 3.1_thick_map.pl";

#system"perl 3.2_interpolation.pl";

system"perl 4_slope_map_data.pl";

#system"perl 4.2_interpolated_thick_map.pl";

system"perl 4.3_slope_map_plot.pl";

system"perl 5_slope_vs_slope_data.pl";

#system"perl 5.2_thick_vs_thick_data.pl";

system"perl 5.4_slope_vs_slope_plot.pl";

system"perl 6_slope_vs_thick_data.pl";

#system"perl 6.2_thick_vs_thick_plot.pl";

system"perl 7_slope_vs_thick_plot.pl";
