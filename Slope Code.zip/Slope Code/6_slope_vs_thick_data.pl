#perl script to merge slope and thickness data


#execute scripts
#merge data
system"perl scripts/slope_vs_thick_merge.pl generated_data/avg_slope_merge.dat generated_data/thickness.dat > generated_data/avg_slopevthick_merge.dat";

#check for slope values of zero (not always necessary)
#system"perl scripts/nonzero.pl generated_data/avg_slopevthick_merge.dat > generated_data/avg_slopevthick_merge_nonzero.dat";

