#perl script to merge elevation data and calculate thickness

#first part merges base and flow surface elevation with the base surface file being input before the flow surface
#second half calculates the thickness for the merged data with final output being a file with 'easting northing thickness'

#execute scripts
system"perl scripts/merge.pl generated_data/base_surface_elevation.dat generated_data/flow_surface_elevation.dat > generated_data/merged_surface_elevation_test.dat";

system"perl scripts/thick.pl generated_data/merged_surface_elevation.dat > generated_data/thickness.dat";
