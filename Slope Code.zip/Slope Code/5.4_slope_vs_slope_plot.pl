#perl script to run gnuplot scrpits to create base vs flow slope plots



#before running: data files must be merged through the slopevslope pl script



#execute scripts
system"gnuplot scripts/avg_slope_plot.gnu";
