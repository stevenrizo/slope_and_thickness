#perl script to reduce large data set to the points of a smaller data set

#first input is a thickness data set with "easting northing elevation"
#second input is slope calculation output with "Easting Northing PlanarSlope MaxSlope FiniteDifferenceSlope AverageSlope AverageEastingGradient AverageNorthingGradient"

#execute scripts
system"perl scripts/data_clip.pl generated_data/base_surface_elevation.dat generated_data/base_slope.dat > generated_data/base_surface_slope.dat";

system"perl scripts/data_clip.pl generated_data/flow_surface_elevation.dat generated_data/flow_slope.dat > generated_data/flow_surface_slope.dat";