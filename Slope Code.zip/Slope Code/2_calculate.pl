#perl script to run average slope calculations on formatted data

#before running: open the formatted data file for the flow elevation data, and input the data for the first line into avg_slope.pl code being used below

#execute scripts
system"perl scripts/avg_slope.pl generated_data/full_base_elevation.dat > generated_data/base_slope.dat";

system"perl scripts/avg_slope.pl generated_data/full_flow_elevation.dat > generated_data/flow_slope.dat";
